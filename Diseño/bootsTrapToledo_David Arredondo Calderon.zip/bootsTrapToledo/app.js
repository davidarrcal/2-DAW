"use strict;"
function cargarVideo(videos) {
window.location.href= `indexx.php?videos=${videos}`; 
}